<?php
include "koneksi.php";

if(isset($_POST['kirim']))
{

    $nama_lengkap   = $_POST['nama_lengkap']; 
    $email          = $_POST['email'];
    $nik            = $_POST['nik'];
    $tempat_lahir   = $_POST['tempat_lahir'];
    $tanggal_lahir  = $_POST['tanggal_lahir'];
    $jenis_kelamin  = $_POST['jenis_kelamin'];
    $jenis_vaksin   = $_POST['jenis_vaksin'];
    $dokter         = $_POST['dokter'];
    $tempat_vaksin  = $_POST['tempat_vaksin'];
    $nomor_ponsel   = $_POST['nomor_ponsel'];
    $alamat         = $_POST['alamat'];
    $alamat_nik     = $_POST['alamat_nik'];

    $simpan = "INSERT INTO formulir_pendaftaran(nama_lengkap,email,nik,tempat_lahir,tanggal_lahir,jenis_kelamin,jenis_vaksin,dokter,tempat_vaksin,nomor_ponsel,alamat,alamat_nik)
        VALUES('$nama_lengkap','$email','$nik','$tempat_lahir','$tanggal_lahir','$jenis_kelamin','$jenis_vaksin','$dokter','$tempat_vaksin','$nomor_ponsel','$alamat','$alamat_nik')";

    $result = mysqli_query($conn,$simpan);

    if($result)
    {
        echo"<script>alert('Data telah berhasil di simpan');window.location='./certificate.php'</script>";
    }
}
{

    $nama_lengkap   = $_POST['nama_lengkap']; 
    $nik            = $_POST['nik'];
    $jenis_vaksin   = $_POST['jenis_vaksin'];

    $simpan = "INSERT INTO jenis_vaksin(nama_lengkap,nik,jenis_vaksin)
        VALUES('$nama_lengkap','$nik','$jenis_vaksin')";

    $result = mysqli_query($conn,$simpan);

    if($result)
    {
        echo"<script>alert('Data telah berhasil di simpan');window.location='./certificate.php'</script>";
    }
}
if(isset($_POST['kirim']))
{

    $nama_lengkap   = $_POST['nama_lengkap']; 
    $nik            = $_POST['nik'];
    $kelurahan      = $_POST['kelurahan'];

    $simpan = "INSERT INTO kelurahan(nama_lengkap,nik,kelurahan)
        VALUES('$nama_lengkap','$nik','$kelurahan')";

    $result = mysqli_query($conn,$simpan);

    if($result)
    {
        echo"<script>alert('Data telah berhasil di simpan');window.location='./certificate.php'</script>";
    }
}
{

    $nama_lengkap   = $_POST['nama_lengkap']; 
    $nik            = $_POST['nik'];
    $dokter         = $_POST['dokter'];

    $simpan = "INSERT INTO dokter_vaksin(nama_lengkap,nik,dokter)
        VALUES('$nama_lengkap','$nik','$dokter')";

    $result = mysqli_query($conn,$simpan);

    if($result)
    {
        echo"<script>alert('Data telah berhasil di simpan');window.location='./certificate.php'</script>";
    }
}
{

    $nama_lengkap   = $_POST['nama_lengkap']; 
    $nik            = $_POST['nik'];
    $tempat_vaksin  = $_POST['tempat_vaksin'];

    $simpan = "INSERT INTO lokasi(nama_lengkap,nik,tempat_vaksin)
        VALUES('$nama_lengkap','$nik','$tempat_vaksin')";

    $result = mysqli_query($conn,$simpan);

    if($result)
    {
        echo"<script>alert('Data telah berhasil di simpan');window.location='./certificate.php'</script>";
    }
}
?>