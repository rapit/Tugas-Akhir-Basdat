<?php
include "koneksi.php";

if(isset($_POST['home']))
{
    if($_POST['home']))
    {
        echo"<script>alert('Data telah berhasil di simpan');window.location='../admin/index.php'</script>";
    }
}
?>