<!DOCTYPE html>
<html>
    <head>
        <title>Formulir Pendaftaran</title>
        <link rel="stylesheet" href="./style1.css">
    </head>
    <body>
        <div style="background-color: #FFFFFF6B;width: 50%;margin: auto;padding: 5px; border-radius: 10px; font-family: open sans-serif;">
        <h1 style="text-align: center;">Daftar Vaksin</h1>
        <form action="form_aksi.php" method="POST">
            <table style="margin: auto;">
                <tr>
                    <td>Nama Lengkap</td>
                    <td> : </td>
                    <td><input type="text" name="nama_lengkap" placeholder="Masukan Nama Lengkap"></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td> : </td>
                    <td><input type="email" name="email" placeholder="Masukan Email"></td>
                </tr>
                <tr>
                    <td>NIK</td>
                    <td> : </td>
                    <td><input type="text" name="nik"placeholder="NIK sesuai KTP"></td>
                </tr>
                <tr>
                    <td>Tempat Lahir</td>
                    <td> : </td>
                    <td><input type="text" name="tempat_lahir" placeholder="Masukan Tempat Lahir"></td>
                </tr>
                <tr>
                    <td>Tanggal Lahir</td>
                    <td> : </td>
                    <td><input type="date" name="tanggal_lahir"  placeholder="Pilih Jenis Kelamin"></td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td> : </td>
                    <td>
                        <select name="jenis_kelamin">
                            <option>*Pilih Jenis Kelamin*</option>
                            <option>Laki-Laki</option>
                            <option>Perempuan</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Jenis Vaksin</td>
                    <td> : </td>
                    <td>
                        <select name="jenis_vaksin">
                            <option>*Pilih Jenis Vaksin*</option>
                            <option>Sinovac</option>
                            <option>Pfizer</option>
                            <option>Astra</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Nama Dokter</td>
                    <td> : </td>
                    <td>
                        <select name="dokter">
                            <option>*Nama Dokter*</option>
                            <option> dr. Riana Jeany Sp.PA </option>
                            <option> dr. Nur Sulthan Sp.PA</option>
                            <option> dr. Rafif Idul Fitra Sp.PA </option>
                            <option> dr. Muhammad Rizki A. Sp.PA</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Tempat Vaksin</td>
                    <td> : </td>
                    <td>
                        <select name="tempat_vaksin">
                            <option>*Pilih Tempat Vaksin*</option>
                            <option>Puskesmas KP. Manggis</option>
                            <option>Puskesmas Cangkurawok</option>
                            <option>Puskesmas Dramaga</option>
                            <option>Poliklinik IPB</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Nomor Ponsel</td>
                    <td> : </td>
                    <td><input type="text" name="nomor_ponsel" placeholder="No. HP yang Aktif"></td>
                </tr>
                <tr>
                    <td>Kelurahan</td>
                    <td> : </td>
                    <td>
                        <select name="kelurahan">
                            <option>*Kelurahan*</option>
                            <option>Babakan</option>
                            <option>Ciherang</option>
                            <option>Cikarawang</option>
                            <option>Dramaga</option>
                            <option>Neglasari</option>
                            <option>Petir</option>
                            <option>Purwasari</option>
                            <option>Sinar Sari</option>
                            <option>Sukadamai</option>
                            <option>Sukawening</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Alamat NIK</td>
                    <td> : </td>
                    <td><textarea name="alamat_nik" placeholder="Alamat sesuai KTP"></textarea></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td>
                        <button type="submit" name="kirim">Kirim</button>
                        <button type="reset" name="reset">Batal</button>
                    </td>
                </tr>
            </table>
        </div>
    </body>
</html>