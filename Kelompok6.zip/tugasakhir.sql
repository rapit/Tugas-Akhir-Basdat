-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 18, 2021 at 11:15 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tugasakhir`
--

-- --------------------------------------------------------

--
-- Table structure for table `dokter_vaksin`
--

CREATE TABLE `dokter_vaksin` (
  `id_dokter` int(11) NOT NULL,
  `nama_lengkap` varchar(60) NOT NULL,
  `nik` varchar(60) NOT NULL,
  `dokter` varchar(60) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dokter_vaksin`
--

INSERT INTO `dokter_vaksin` (`id_dokter`, `nama_lengkap`, `nik`, `dokter`, `waktu`) VALUES
(1, 'rasdasd', '1212412', 'dr. Rafif Idul Fitra Sp.PA', '2021-12-09 13:06:16'),
(2, 'aaaaaa', '111111111', 'dr. Nur Sulthan Sp.PA', '2021-12-09 15:38:11'),
(3, 'aaaaaab', '111111111b', 'dr. Rafif Idul Fitra Sp.PA', '2021-12-09 15:41:00'),
(4, 'afas', '242134', 'dr. Muhammad Rizki A. Sp.PA', '2021-12-14 03:14:57'),
(5, 'dsdasdasdass', 'sa', 'dr. Riana Jeany Sp.PA', '2021-12-14 04:45:11'),
(6, 'muhammad adiyaksa', '312312312', 'dr. Rafif Idul Fitra Sp.PA', '2021-12-17 09:05:28'),
(7, 'dsadada', '23432423', 'dr. Nur Sulthan Sp.PA', '2021-12-17 09:11:17');

-- --------------------------------------------------------

--
-- Table structure for table `formulir_pendaftaran`
--

CREATE TABLE `formulir_pendaftaran` (
  `id_formulir` int(11) NOT NULL,
  `nama_lengkap` varchar(60) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nik` varchar(60) NOT NULL,
  `tempat_lahir` varchar(100) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `jenis_kelamin` varchar(30) NOT NULL,
  `jenis_vaksin` varchar(60) NOT NULL,
  `dokter` varchar(60) NOT NULL,
  `tempat_vaksin` varchar(100) NOT NULL,
  `nomor_ponsel` varchar(30) NOT NULL,
  `kelurahan` text NOT NULL,
  `alamat_nik` text NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `formulir_pendaftaran`
--

INSERT INTO `formulir_pendaftaran` (`id_formulir`, `nama_lengkap`, `email`, `nik`, `tempat_lahir`, `tanggal_lahir`, `jenis_kelamin`, `jenis_vaksin`, `dokter`, `tempat_vaksin`, `nomor_ponsel`, `kelurahan`, `alamat_nik`, `waktu`) VALUES
(12, 'eqwe', 'rapitidulfitra4@gmail.com', '13123', 'dad', '2021-12-06', 'Laki-Laki', 'Sinovac', 'dr. Riana Jeany Sp.PA', 'Puskesmas KP. Manggis', '123', 'adas', 'asda', '2021-12-09 12:21:31'),
(13, '', '', '', '', '0000-00-00', '*Pilih Jenis Kelamin*', '*Pilih Jenis Vaksin*', '*Nama Dokter*', '*Pilih Tempat Vaksin*', '', '', '', '2021-12-09 12:21:31'),
(14, 'rafif', 'rapitidulfitra5@gmail.com', '213123', 'asdas', '2021-12-07', 'Laki-Laki', 'Sinovac', 'dr. Riana Jeany Sp.PA', 'Puskesmas Cangkurawok', '04214124', 'acfsa', 'asasad', '2021-12-09 12:21:31'),
(15, '', '', '', '', '0000-00-00', '*Pilih Jenis Kelamin*', '*Pilih Jenis Vaksin*', '*Nama Dokter*', '*Pilih Tempat Vaksin*', '', '', '', '2021-12-09 12:21:31'),
(16, '', '', '', '', '0000-00-00', '*Pilih Jenis Kelamin*', '*Pilih Jenis Vaksin*', '*Nama Dokter*', '*Pilih Tempat Vaksin*', '', '', '', '2021-12-09 12:21:31'),
(17, '', '', '', '', '0000-00-00', '*Pilih Jenis Kelamin*', '*Pilih Jenis Vaksin*', '*Nama Dokter*', '*Pilih Tempat Vaksin*', '', '', '', '2021-12-09 12:21:31'),
(18, 'rasd', 'dsadasdasd@fsfdafas', '1212412', 'adqwe', '2003-12-14', 'Laki-Laki', 'Sinovac', 'dr. Riana Jeany Sp.PA', 'Puskesmas Cangkurawok', '221123', 'rfasf', 'asdad', '2021-12-09 12:36:45'),
(19, 'rasdasd', 'dsadad@fsfdafas', '1212412', 'adqwe', '2003-12-14', 'Laki-Laki', 'Sinovac', 'dr. Riana Jeany Sp.PA', 'Puskesmas Cangkurawok', '221123', 'Dramaga', 'asdad', '2021-12-09 12:52:42'),
(20, 'rasdasd', 'dsadad@fsfdafas', '1212412', 'adqwe', '2003-12-14', 'Laki-Laki', 'Sinovac', 'dr. Riana Jeany Sp.PA', 'Puskesmas Cangkurawok', '221123', 'Dramaga', 'asdad', '2021-12-09 12:53:14'),
(21, 'rasdasd', 'dsadad@fsfdafas', '1212412', 'adqwe', '2003-12-14', 'Laki-Laki', 'Sinovac', 'dr. Riana Jeany Sp.PA', 'Puskesmas Cangkurawok', '221123', 'Dramaga', 'asdad', '2021-12-09 12:58:18'),
(22, 'rasdasd', 'dsadad@fsfdafas', '1212412', 'adqwe', '2003-12-14', 'Laki-Laki', 'Sinovac', 'dr. Rafif Idul Fitra Sp.PA', 'Puskesmas Cangkurawok', '221123', 'Dramaga', 'asdad', '2021-12-09 13:06:16'),
(23, 'aaaaaa', 'aaaaaa@aaa', '111111111', 'aaaa', '2021-12-21', 'Laki-Laki', 'Sinovac', 'dr. Nur Sulthan Sp.PA', 'Puskesmas KP. Manggis', '3333333333', 'Sinar Sari', 'aaaaaaa', '2021-12-09 15:38:11'),
(24, 'aaaaaab', 'aaaaaa@aaab', '111111111b', 'aaaab', '2021-12-21', 'Laki-Laki', 'Sinovac', 'dr. Rafif Idul Fitra Sp.PA', 'Puskesmas Dramaga', '3333333333b', 'Petir', 'aaaaaaab', '2021-12-09 15:41:00'),
(25, 'afas', 'rapitidulfitra@gmail.com', '242134', 'sfdsd', '2021-12-13', 'Laki-Laki', 'Pfizer', 'dr. Muhammad Rizki A. Sp.PA', 'Poliklinik IPB', '23234', 'Ciherang', 'esfdfs', '2021-12-14 03:14:57'),
(26, 'dsdasdasdass', 'dsadad@fsfdafas', 'sa', 'sad', '2021-12-07', 'Laki-Laki', 'Sinovac', 'dr. Riana Jeany Sp.PA', 'Puskesmas KP. Manggis', '212', 'Babakan', 'adsa', '2021-12-14 04:45:11'),
(27, 'muhammad adiyaksa', 'rizki@gmail.com', '312312312', 'fsdfdsfsd', '2021-12-02', 'Laki-Laki', 'Pfizer', 'dr. Rafif Idul Fitra Sp.PA', 'Puskesmas KP. Manggis', '392839283928', 'Dramaga', 'fsfsfasafsdfdsd', '2021-12-17 09:05:28'),
(28, 'dsadada', 'dasdasdas@asas', '23432423', 'fsdfxcfsd', '2021-12-07', 'Laki-Laki', 'Sinovac', 'dr. Nur Sulthan Sp.PA', 'Puskesmas Dramaga', '2341231', 'Babakan', 'dasdasda', '2021-12-17 09:11:17');

-- --------------------------------------------------------

--
-- Table structure for table `jenis_vaksin`
--

CREATE TABLE `jenis_vaksin` (
  `id_Jenis` int(11) NOT NULL,
  `nama_lengkap` varchar(60) NOT NULL,
  `nik` varchar(60) NOT NULL,
  `jenis_vaksin` varchar(60) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jenis_vaksin`
--

INSERT INTO `jenis_vaksin` (`id_Jenis`, `nama_lengkap`, `nik`, `jenis_vaksin`, `waktu`) VALUES
(1, 'rasd', '1212412', 'Sinovac', '2021-12-09 12:36:45'),
(2, 'rasdasd', '1212412', 'Sinovac', '2021-12-09 12:52:42'),
(3, 'rasdasd', '1212412', 'Sinovac', '2021-12-09 12:53:14'),
(4, 'rasdasd', '1212412', 'Sinovac', '2021-12-09 12:58:18'),
(5, 'rasdasd', '1212412', 'Sinovac', '2021-12-09 13:06:16'),
(6, 'aaaaaa', '111111111', 'Sinovac', '2021-12-09 15:38:11'),
(7, 'aaaaaab', '111111111b', 'Sinovac', '2021-12-09 15:41:00'),
(8, 'afas', '242134', 'Pfizer', '2021-12-14 03:14:57'),
(9, 'dsdasdasdass', 'sa', 'Sinovac', '2021-12-14 04:45:11'),
(10, 'muhammad adiyaksa', '312312312', 'Pfizer', '2021-12-17 09:05:28'),
(11, 'dsadada', '23432423', 'Sinovac', '2021-12-17 09:11:17');

-- --------------------------------------------------------

--
-- Table structure for table `kelurahan`
--

CREATE TABLE `kelurahan` (
  `id_kelurahan` int(11) NOT NULL,
  `nama_lengkap` varchar(60) NOT NULL,
  `nik` varchar(60) NOT NULL,
  `kelurahan` varchar(60) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kelurahan`
--

INSERT INTO `kelurahan` (`id_kelurahan`, `nama_lengkap`, `nik`, `kelurahan`, `waktu`) VALUES
(1, 'rasdasd', '1212412', 'Dramaga', '2021-12-09 12:53:14'),
(2, 'rasdasd', '1212412', 'Dramaga', '2021-12-09 12:58:18'),
(3, 'rasdasd', '1212412', 'Dramaga', '2021-12-09 13:06:16'),
(4, 'aaaaaa', '111111111', 'Sinar Sari', '2021-12-09 15:38:11'),
(5, 'aaaaaab', '111111111b', 'Petir', '2021-12-09 15:41:00'),
(6, 'afas', '242134', 'Ciherang', '2021-12-14 03:14:57'),
(7, 'dsdasdasdass', 'sa', 'Babakan', '2021-12-14 04:45:11'),
(8, 'muhammad adiyaksa', '312312312', 'Dramaga', '2021-12-17 09:05:28'),
(9, 'dsadada', '23432423', 'Babakan', '2021-12-17 09:11:17');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id_login` int(11) NOT NULL,
  `username` varchar(60) NOT NULL,
  `pasword` varchar(30) DEFAULT NULL,
  `nama` varchar(30) DEFAULT NULL,
  `email` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id_login`, `username`, `pasword`, `nama`, `email`) VALUES
(11, 'rapitidulfitra', 'padang', 'Rafif Idul Fitra', 'rapitidulfitra@gmail.com'),
(12, 'rizki_aksa', 'sedapmalam10', 'rizki adiyaksa', 'rizki@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `lokasi`
--

CREATE TABLE `lokasi` (
  `id_lokasi` int(11) NOT NULL,
  `nama_lengkap` varchar(60) NOT NULL,
  `nik` varchar(60) NOT NULL,
  `tempat_vaksin` varchar(60) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lokasi`
--

INSERT INTO `lokasi` (`id_lokasi`, `nama_lengkap`, `nik`, `tempat_vaksin`, `waktu`) VALUES
(1, 'rasdasd', '1212412', 'Puskesmas Cangkurawok', '2021-12-09 12:58:18'),
(2, 'aaaaaab', '111111111b', 'Puskesmas Dramaga', '2021-12-09 15:41:00'),
(3, 'afas', '242134', 'Poliklinik IPB', '2021-12-14 03:14:57'),
(4, 'dsdasdasdass', 'sa', 'Puskesmas KP. Manggis', '2021-12-14 04:45:11'),
(5, 'muhammad adiyaksa', '312312312', 'Puskesmas KP. Manggis', '2021-12-17 09:05:28'),
(6, 'dsadada', '23432423', 'Puskesmas Dramaga', '2021-12-17 09:11:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dokter_vaksin`
--
ALTER TABLE `dokter_vaksin`
  ADD PRIMARY KEY (`id_dokter`);

--
-- Indexes for table `formulir_pendaftaran`
--
ALTER TABLE `formulir_pendaftaran`
  ADD PRIMARY KEY (`id_formulir`);

--
-- Indexes for table `jenis_vaksin`
--
ALTER TABLE `jenis_vaksin`
  ADD PRIMARY KEY (`id_Jenis`);

--
-- Indexes for table `kelurahan`
--
ALTER TABLE `kelurahan`
  ADD PRIMARY KEY (`id_kelurahan`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id_login`);

--
-- Indexes for table `lokasi`
--
ALTER TABLE `lokasi`
  ADD PRIMARY KEY (`id_lokasi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dokter_vaksin`
--
ALTER TABLE `dokter_vaksin`
  MODIFY `id_dokter` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `formulir_pendaftaran`
--
ALTER TABLE `formulir_pendaftaran`
  MODIFY `id_formulir` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `jenis_vaksin`
--
ALTER TABLE `jenis_vaksin`
  MODIFY `id_Jenis` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `kelurahan`
--
ALTER TABLE `kelurahan`
  MODIFY `id_kelurahan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id_login` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `lokasi`
--
ALTER TABLE `lokasi`
  MODIFY `id_lokasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
