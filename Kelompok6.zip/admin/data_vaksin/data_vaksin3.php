<?php
$conn = mysqli_connect("localhost","root","","TugasAkhir");
$Sinovac = $conn->query("select * from jenis_vaksin where jenis_vaksin='Sinovac'");
$jml_sinovac = $Sinovac->num_rows;

$Pfizer = $conn->query("select * from jenis_vaksin where jenis_vaksin='Pfizer'");
$jml_Pfizer = $Pfizer->num_rows;

$Astra = $conn->query("select * from jenis_vaksin where jenis_vaksin='Astra'");
$jml_Astra = $Astra->num_rows;
?>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
    google.charts.load("current", {
        packages: ['corechart']
    });
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
        var data = google.visualization.arrayToDataTable([
            ["Element", "Density", {
                role: "style"
            }],
            ["Sinovac",<?php echo $jml_sinovac ?>, "#b87333"],
            ["Pfizer", <?php echo $jml_Pfizer ?>, "silver"],
            ["Astra",<?php echo $jml_Astra ?>, "gold"]
        ]);

        var view = new google.visualization.DataView(data);
        view.setColumns([0, 1,
            {
                calc: "stringify",
                sourceColumn: 1,
                type: "string",
                role: "annotation"
            },
            2
        ]);

        var options = {
            title: "JUMLAH DATA PASIEN VAKSIN - JENIS VAKSIN",
            width: 600,
            height: 400,
            bar: {
                groupWidth: "95%"
            },
            legend: {
                position: "none"
            },
        };
        var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
        chart.draw(view, options);
    }
</script>
<body style="background-color: darkturquoise;"></body>
<div id="columnchart_values" style="width: 900px; height: 300px;"></div>
<html>
    <head style="background-color: darkturquoise;">
        <body>
        <tr>
                    <td></td><br></br><br></br><br></br><br></br>
                    <td><a href="./data_vaksin1.php" > JUMLAH DATA PASIEN VAKSIN - KELURAHAN</a></td> </br>
                    <td>
                        <a href="./data_vaksin2.php" >JUMLAH DATA PASIEN VAKSIN - TEMPAT VAKSIN</a>
                    </td>
                </tr>
        </body>
    </head>
</html>
