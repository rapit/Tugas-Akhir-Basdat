<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="">
    <meta name="author" content="">

    <title>VACCINOW</title>

    <!-- CSS FILES -->
    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/bootstrap-icons.css" rel="stylesheet">

    <link href="css/owl.carousel.min.css" rel="stylesheet">

    <link href="css/owl.theme.default.min.css" rel="stylesheet">

    <link href="css/projectakhirkelompok6.css" rel="stylesheet">

</head>

<body id="top">

    <main>

        <nav class="navbar navbar-expand-lg bg-light fixed-top shadow-lg">
            <div class="container">
                <a class="navbar-brand mx-auto d-lg-none" href="index.html">
                    Vaccinow
                    <strong class="d-block">Vaccine Mediator</strong>
                </a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav mx-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="#hero">Home</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="#about">About Us</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="#timeline">Timeline</a>
                        </li>

                        <a class="navbar-brand d-none d-lg-block" href="index.html">
                            Vaccinow
                            <strong class="d-block">Vaccine Mediator</strong>
                        </a>

                        <li class="nav-item">
                            <a class="nav-link" href="#reviews">Testimonials</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="./data_vaksin/data_vaksin1.php">Data Vaccine</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="../pendaftaran/formulir.php">Register Vaccine</a>
                        </li>
                    </ul>
                </div>

            </div>
        </nav>

        <section class="hero" id="hero">
            <div class="container">
                <div class="row">

                    <div class="col-12">
                        <div id="myCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img src="images/project/moderna.jpg" class="img-fluid" alt="">
                                </div>

                                <div class="carousel-item">
                                    <img src="images/project/pfizer.jpg" class="img-fluid" alt="">
                                </div>

                                <div class="carousel-item">
                                    <img src="images/project/astrazeneca.jpg" class="img-fluid" alt="">
                                </div>
                            </div>
                        </div>

                        <div class="heroText d-flex flex-column justify-content-center">

                            <h1 class="mt-auto mb-2">
                                Better
                                <div class="animated-info">
                                    <span class="animated-item">health</span>
                                    <span class="animated-item">days</span>
                                    <span class="animated-item">lives</span>
                                </div>
                            </h1>

                            <p class="mb-4">GET YOUR VACCINE WITH VACCINOW</p>

                            <div class="heroLinks d-flex flex-wrap align-items-center">
                                <a class="custom-link me-4" href="#about" data-hover="Learn More">Learn More</a>

                                <p class="contact-phone mb-0"><i class="bi-phone"></i> (0251)87987697</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <section class="section-padding" id="about">
            <div class="container">
                <div class="row">

                    <div class="col-lg-6 col-md-6 col-12">
                        <h2 class="mb-lg-3 mb-3">Introducing Vaccinow</h2>

                        <p>Vaccinow provides you with the most accurate information about vaccinations in dramaga. Established in 2021, we help you find the best vaccine and vaccine locations that suit you the most.
                        </p>


                    </div>

                    <div class="col-lg-4 col-md-5 col-12 mx-auto">

                        <div class="featured-circle bg-white shadow-lg d-flex justify-content-center align-items-center">
                            <img src="images/project/croplogo.png" class="img-fluid galleryImage" alt="get a vaccine" title="get a vaccine for yourself">
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <section class="gallery">
            <div class="container">
                <div class="row">

                    <div class="col-lg-6 col-6 ps-0">
                        <img src="images/project/orangvaksin.jpg" class="img-fluid galleryImage" alt="get a vaccine" title="get a vaccine for yourself">
                    </div>

                    <div class="col-lg-6 col-6 pe-0">
                        <img src="images/project/orangvaksin2.jpg" class="img-fluid galleryImage" alt="wear a mask" title="wear a mask to protect yourself">
                    </div>

                </div>
            </div>
        </section>

        <section class="section-padding pb-0" id="timeline">
            <div class="container">
                <div class="row">

                    <h2 class="text-center mb-lg-5 mb-4">How to get vaccinated with Vaccinow ?</h2>

                    <div class="timeline">

                        <div class="row g-0 justify-content-end justify-content-md-around align-items-start timeline-nodes">
                            <div class="col-9 col-md-5 me-md-4 me-lg-0 order-3 order-md-1 timeline-content bg-white shadow-lg">
                                <h3 class=" text-light">Login/Sign Up Account</h3>
                                <p>Terimakasih anda telah login</p>
                            </div>
                            <div class="col-3 col-sm-1 order-2 timeline-icons text-md-center">
                                <i class="bi-patch-check-fill timeline-icon"></i>
                            </div>
                            <div class="col-9 col-md-5 ps-md-3 ps-lg-0 order-1 order-md-3 py-4 timeline-date"></div>
                        </div>

                        <div class="row g-0 justify-content-end justify-content-md-around align-items-start timeline-nodes">
                            <div class="col-9 col-md-5 me-md-4 me-lg-0 order-3 order-md-1 timeline-content bg-white shadow-lg">
                                <h3><a class=" text-light" href="#hero">Main Page</a></h3>
                                <p>Anda telah masuk di halaman utama kami</p>
                            </div>

                            <div class="col-3 col-sm-1 order-2 timeline-icons text-md-center">
                                <i class="bi-person timeline-icon"></i>
                            </div>

                            <div class="col-9 col-md-5 ps-md-3 ps-lg-0 order-1 order-md-3 py-4 timeline-date">
                            </div>
                        </div>

                        <div class="row g-0 justify-content-end justify-content-md-around align-items-start timeline-nodes my-lg-5 my-4">
                            <div class="col-9 col-md-5 ms-md-4 ms-lg-0 order-3 order-md-1 timeline-content bg-white shadow-lg">
                                <h3><a class=" text-light" href="../pendaftaran/formulir.php">Register Vaccine</a></h3>
                                <p>Lengkapi data diri Anda untuk pendaftaran vaksin</p>
                            </div>
                            <div class="col-3 col-sm-1 order-2 timeline-icons text-md-center">
                                <i class="bi-book timeline-icon"></i>
                            </div>
                            <div class="col-9 col-md-5 pe-md-3 pe-lg-0 order-1 order-md-3 py-4 timeline-date">
                            </div>
                        </div>

                        <div class="row g-0 justify-content-end justify-content-md-around align-items-start timeline-nodes">
                            <div class="col-9 col-md-5 me-md-4 me-lg-0 order-3 order-md-1 timeline-content bg-white shadow-lg">
                                <h3 class=" text-light">Choose your Vaccine</h3>
                                <p>Pilih vaksin yang sesuai dengan Anda buat</p>
                            </div>
                            <div class="col-3 col-sm-1 order-2 timeline-icons text-md-center">
                                <i class="bi-person timeline-icon"></i>
                            </div>
                            <div class="col-9 col-md-5 ps-md-3 ps-lg-0 order-1 order-md-3 py-4 timeline-date">
                            </div>
                        </div>

                        <div class="row g-0 justify-content-end justify-content-md-around align-items-start timeline-nodes my-lg-5 my-4">
                            <div class="col-9 col-md-5 ms-md-4 ms-lg-0 order-3 order-md-1 timeline-content bg-white shadow-lg">
                                <h3 class=" text-light">Vaccine Locations</h3>
                                <p>Pilih lokasi Vaksin</p>
                            </div>
                            <div class="col-3 col-sm-1 order-2 timeline-icons text-md-center">
                                <i class="bi-globe timeline-icon"></i>
                            </div>
                            <div class="col-9 col-md-5 pe-md-3 pe-lg-0 order-1 order-md-3 py-4 timeline-date">
                            </div>
                        </div>

                        <div class="row g-0 justify-content-end justify-content-md-around align-items-start timeline-nodes my-lg-5 my-4">
                            <div class="col-9 col-md-5 ms-md-4 ms-lg-0 order-3 order-md-1 timeline-content bg-white shadow-lg">
                                <h3 class=" text-light">Vaccine Finished</h3>
                                <p><a href="./logout.php" onclick="return confirm('Yakin ingin logout?')">LogOut</a></p>
                            </div>
                            <div class="col-3 col-sm-1 order-2 timeline-icons text-md-center">
                                <i class="bi-globe timeline-icon"></i>
                            </div>
                            <div class="col-9 col-md-5 pe-md-3 pe-lg-0 order-1 order-md-3 py-4 timeline-date">
                            </div>
                        </div>

                    </div>
                </div>
        </section>

        <section class="section-padding pb-0" id="reviews">
            <div class="container">
                <div class="row">

                    <div class="col-12">
                        <h2 class="text-center mb-lg-5 mb-4">What They Say?</h2>

                        <div class="owl-carousel reviews-carousel">


                            <figure class="reviews-thumb d-flex flex-wrap align-items-center rounded">
                                <div class="reviews-stars">
                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star"></i>
                                </div>
                                <p class="text-primary d-block mt-2 mb-0 w-100"><strong>Sangat interaktif dan mudah digunakan</strong></p>
                                <p class="reviews-text w-100">Untuk orang yang gaptek seperti saya web ini sangat mudah digunakan dan cepat menemuka lokasi vaksin yang dekat dari rumah saya</p>
                                <figcaption class="ms-4">
                                    <strong>Jeffry DD</strong>
                                </figcaption>
                            </figure>

                            <figure class="reviews-thumb d-flex flex-wrap align-items-center rounded">
                                <div class="reviews-stars">
                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star-fill"></i>
                                </div>

                                <p class="text-primary d-block mt-2 mb-0 w-100"><strong>Paling mantap Servis nya!!!</strong></p>
                                <p class="reviews-text w-100">Mantap, Cepat, Tanggap, Server gak pernah Down, Paling ok dari yang lain...</p>

                                <figcaption class="ms-4">
                                    <strong>Sarah Malika</strong>
                                </figcaption>
                            </figure>

                            <figure class="reviews-thumb d-flex flex-wrap align-items-center rounded">
                                <div class="reviews-stars">
                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star"></i>
                                    <i class="bi-star"></i>
                                </div>
                                <p class="text-primary d-block mt-2 mb-0 w-100"><strong>Best UI</strong></p>
                                <p class="reviews-text w-100">Sekarang, semuanya bagus! Setelah pengembang memperbaruinya dan menonaktifkan layanan lokasi sepanjang waktu, tentu saja, aplikasi menjadi lebih baik. Mereka menyediakan bahasa Inggris dan UI yang lebih baik, terima kasih!</p>
                                <figcaption class="ms-4">
                                    <strong>Bayu Nugroho</strong>
                                </figcaption>
                            </figure>

                        </div>

                    </div>

                </div>
            </div>
        </section>

        <section class="section-padding" id="booking">
            <div class="container">
                <div class="row">

                    <div class="col-lg-8 col-12 mx-auto">
                        <div class="booking-form">

                            <form role="form" action="" method="post">
                        </div>
                        </form>

                    </div>
                </div>

            </div>
            </div>
        </section>

    </main>

    <footer class="site-footer section-padding" id="contact">
        <div class="container">
            <div class="row">

                <div class="col-lg-5 me-auto col-12">
                    <h5 class="mb-lg-4 mb-3">Our Partner's</h5>

                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex">
                            Poliklinik IPB
                            <span>Setiap hari</span>
                        </li>
                        <li class="list-group-item d-flex">
                            Puskesmas KP. Manggis
                            <span>Senin dan Rabu</span>
                        </li>
                        <li class="list-group-item d-flex">
                            Puskesmas Cangkurawok
                            <span>Selasa dan Rabu</span>
                        </li>
                        <li class="list-group-item d-flex">
                            Puskesmas Dramaga
                            <span>Selasa dan Rabu</span>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-2 col-md-6 col-12 my-4 my-lg-0">
                    <h5><a class="mb-lg-4 mb-3"  href="../hal_admin/admin.php">Our Office</a></h5>

                    <p><a href="rzkyadiyaksa@apps.ipb.ac.id">vaccinow.co.id</a>
                    <p>

                    <p>Jl. Raya Dramaga, Babakan, Kec. Dramaga, Kota Bogor, Jawa Barat 16680 </p>
                </div>

                <div class="col-lg-3 col-md-6 col-12 ms-auto">
                    <h5 class="mb-lg-4 mb-3">Socials</h5>


                    <ul class="social-icon">
                        <li><a href="#" class="social-icon-link bi-facebook"></a></li>

                        <li><a href="#" class="social-icon-link bi-twitter"></a></li>

                        <li><a href="#" class="social-icon-link bi-instagram"></a></li>

                        <li><a href="#" class="social-icon-link bi-youtube"></a></li>
                    </ul>
                </div>

            </div>
            </section>
    </footer>


    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/scrollspy.min.js"></script>
    <script src="js/custom.js"></script>

</body>

</html>