<?php
include "koneksi.php";

if(isset($_POST['kirim']))
{

    $username   = $_POST['username']; 
    $pasword    = $_POST['pasword'];
    $nama       = $_POST['nama'];
    $email      = $_POST['email'];

    $simpan = "INSERT INTO login(username,pasword,nama,email)
        VALUES('$username','$pasword','$nama','$email')";

    $result = mysqli_query($conn,$simpan);

    if($result)
    {
        echo"<script>alert('Data telah berhasil di simpan');document.location.href='/login'</script>";
    }
}
?>